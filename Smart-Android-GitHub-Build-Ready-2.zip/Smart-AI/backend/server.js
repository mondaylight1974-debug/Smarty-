import express from "express";
import cors from "cors";
const app=express(), port=process.env.PORT||3000;
app.use(cors()); app.use(express.json());
const devices=new Map(), activity=[];
app.get("/api/health",(_,res)=>res.json({ok:true,service:"Smart API",version:"1.0.0"}));
app.post("/api/devices/register",(req,res)=>{
 const {deviceId,name,platform="android"}=req.body||{};
 if(!deviceId)return res.status(400).json({error:"deviceId required"});
 const d={deviceId,name:name||"Android device",platform,authorized:false,updatedAt:new Date().toISOString()};
 devices.set(deviceId,d); res.json(d);
});
app.get("/api/devices",(_,res)=>res.json([...devices.values()]));
app.post("/api/command",(req,res)=>{
 const command=String(req.body?.command||"").trim();
 if(!command)return res.status(400).json({error:"command required"});
 const item={id:crypto.randomUUID(),command,deviceId:req.body?.deviceId||null,status:"received",createdAt:new Date().toISOString()};
 activity.push(item); res.json({ok:true,message:`Smart received: "${command}"`,commandId:item.id,status:item.status});
});
app.get("/api/activity",(_,res)=>res.json(activity.slice(-100).reverse()));
app.listen(port,()=>console.log(`Smart API listening on ${port}`));