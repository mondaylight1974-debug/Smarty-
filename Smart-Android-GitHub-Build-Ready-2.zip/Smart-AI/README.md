# Smart AI
A modular Android-first AI assistant starter.

## Build
Open `android/SmartAgent` in AIDE or Android Studio and build/run it.

## Backend
From `backend/` run:
npm install
npm start

## Important
Android device actions require explicit user authorization and supported Android APIs. This project does not bypass Android security.
