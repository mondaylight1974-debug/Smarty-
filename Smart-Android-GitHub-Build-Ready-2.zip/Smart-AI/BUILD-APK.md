# Smart — easiest APK build

This project is prepared for GitHub Actions. You do **not** need Android Studio or AndroidIDE.

1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Open **Build Smart APK** and press **Run workflow**.
4. Wait for the green check mark.
5. Open the completed workflow run, scroll to **Artifacts**, and download **Smart-debug-APK**.
6. On your Android phone, open the downloaded ZIP and install `app-debug.apk`.

The APK is a debug build intended for direct installation/testing. A signed release build can be prepared later for Google Play or commercial distribution.
