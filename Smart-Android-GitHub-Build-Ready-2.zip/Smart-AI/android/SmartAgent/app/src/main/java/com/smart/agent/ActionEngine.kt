package com.smart.agent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
class ActionEngine(private val context: Context){
 fun execute(command:String):ActionResult{val t=command.trim();val l=t.lowercase();return when{
 l.startsWith("open http://")||l.startsWith("open https://")->openUrl(t.substringAfter("open "))
 l.startsWith("open website ")->openUrl(t.substringAfter("open website "))
 l=="open settings"->launch(Intent(Settings.ACTION_SETTINGS),"Settings opened.")
 l=="open accessibility settings"->launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),"Accessibility settings opened.")
 l=="open notification access"->launch(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"),"Notification access settings opened.")
 l.startsWith("call ")->launch(Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+t.substringAfter("call ").replace(Regex("[^+0-9*#]"),""))),"Dialer opened.")
 l.startsWith("send sms ")->sms(t.substringAfter("send sms "))
 l.startsWith("set alarm ")->alarm(t.substringAfter("set alarm "))
 l=="home"->ActionResult(SmartAccessibilityService.instance?.goHome()==true,"Home requested.")
 l=="back"->ActionResult(SmartAccessibilityService.instance?.goBack()==true,"Back requested.")
 l=="recent apps"->ActionResult(SmartAccessibilityService.instance?.openRecents()==true,"Recent apps requested.")
 l.startsWith("open ")->openApp(t.substringAfter("open "))
 else->ActionResult(false,"Command not mapped yet.")}}
 private fun openUrl(raw:String):ActionResult{val u=if(raw.startsWith("http"))raw else "https://$raw";return launch(Intent(Intent.ACTION_VIEW,Uri.parse(u)),"Website launched.")}
 private fun sms(raw:String):ActionResult{val p=raw.split("|",limit=2);if(p.size<2)return ActionResult(false,"Use: send sms PHONE | MESSAGE");return launch(Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:${p[0].trim()}")).putExtra("sms_body",p[1].trim()),"SMS composer opened for confirmation.")}
 private fun alarm(raw:String):ActionResult{val p=raw.split(":");if(p.size!=2)return ActionResult(false,"Use: set alarm HH:MM");val h=p[0].toIntOrNull()?:return ActionResult(false,"Invalid hour");val m=p[1].toIntOrNull()?:return ActionResult(false,"Invalid minute");return launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR,h).putExtra(AlarmClock.EXTRA_MINUTES,m),"Alarm screen opened.")}
 private fun openApp(name:String):ActionResult{val pkg=when(name.lowercase()){"youtube"->"com.google.android.youtube";"whatsapp"->"com.whatsapp";"chrome","google chrome"->"com.android.chrome";"settings"->"com.android.settings";else->return ActionResult(false,"No safe package mapping for $name")};val i=context.packageManager.getLaunchIntentForPackage(pkg)?:return ActionResult(false,"App is not installed.");return launch(i,"$name opened.")}
 private fun launch(i:Intent,msg:String)=try{i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);context.startActivity(i);ActionResult(true,msg)}catch(e:Exception){ActionResult(false,e.message?:"Android action failed")}
}
