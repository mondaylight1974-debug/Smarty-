package com.smart.agent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
class SmartNotificationListenerService:NotificationListenerService(){companion object{var latest=""}override fun onNotificationPosted(sbn:StatusBarNotification){latest=sbn.packageName}}
