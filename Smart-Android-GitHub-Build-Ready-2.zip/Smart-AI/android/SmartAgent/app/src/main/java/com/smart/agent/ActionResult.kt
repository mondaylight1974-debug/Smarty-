package com.smart.agent
data class ActionResult(val success:Boolean,val message:String)
