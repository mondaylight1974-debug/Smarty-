package com.smart.agent
import android.os.Bundle
import android.graphics.Color
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity:AppCompatActivity(){
 private lateinit var messages:LinearLayout
 private lateinit var input:EditText
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
  messages=findViewById(R.id.messages); input=findViewById(R.id.commandInput)
  findViewById<Button>(R.id.sendButton).setOnClickListener{
   val c=input.text.toString().trim()
   if(c.isNotEmpty()){add(c,true);input.text.clear();add("Smart received your command. Connect the backend to process it.",false)}
  }
  findViewById<Button>(R.id.devicesButton).setOnClickListener{add("Device management: authorization is required before device actions.",false)}
  findViewById<Button>(R.id.activityButton).setOnClickListener{add("Activity: commands will appear here when the API is connected.",false)}
  add("Hello. I am Smart. Your assistant is ready.",false)
 }
 private fun add(t:String,user:Boolean){
  val v=TextView(this); v.text=t; v.textSize=16f; v.setTextColor(Color.WHITE); v.setPadding(18,14,18,14); v.setBackgroundColor(if(user)0x663F51B5 else 0x55333355); messages.addView(v)
 }
}