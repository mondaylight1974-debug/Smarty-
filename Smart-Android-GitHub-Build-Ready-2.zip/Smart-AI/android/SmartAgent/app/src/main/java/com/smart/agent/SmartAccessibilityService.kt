package com.smart.agent
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
class SmartAccessibilityService:AccessibilityService(){companion object{var instance:SmartAccessibilityService?=null}override fun onServiceConnected(){instance=this}override fun onAccessibilityEvent(event:AccessibilityEvent?){ }override fun onInterrupt(){}override fun onDestroy(){instance=null;super.onDestroy()}fun goHome()=performGlobalAction(GLOBAL_ACTION_HOME);fun goBack()=performGlobalAction(GLOBAL_ACTION_BACK);fun openRecents()=performGlobalAction(GLOBAL_ACTION_RECENTS)}
