create table if not exists users(id uuid primary key default gen_random_uuid(),email text unique not null,plan text default 'free',created_at timestamptz default now());
create table if not exists devices(id uuid primary key default gen_random_uuid(),user_id uuid references users(id),device_id text unique not null,name text,authorized boolean default false,last_seen timestamptz);
create table if not exists audit_logs(id uuid primary key default gen_random_uuid(),user_id uuid references users(id),device_id text,action text,result text,created_at timestamptz default now());
create table if not exists subscriptions(id uuid primary key default gen_random_uuid(),user_id uuid references users(id),provider text,provider_reference text,plan text,status text,created_at timestamptz default now());
